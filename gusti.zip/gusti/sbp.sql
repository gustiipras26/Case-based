-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2020 at 07:04 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sbp`
--

-- --------------------------------------------------------

--
-- Table structure for table `basispengetahuan`
--

CREATE TABLE `basispengetahuan` (
  `namapenyakit` varchar(100) NOT NULL,
  `gejala` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `basispengetahuan`
--

INSERT INTO `basispengetahuan` (`namapenyakit`, `gejala`) VALUES
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('Scabies', 'Keropeng'),
('Scabies', 'Ketombe'),
('Scabies', 'Kutuan'),
('Scabies', 'Kurus'),
('Scabies', 'Bulu Rontok'),
('Scabies', 'Hilang Nafsu Makan'),
('Scabies', 'Jamur'),
('Scabies', 'Fases Lembek'),
('Scabies', 'Tidak Mau Makan');

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE `gejala` (
  `idgejala` varchar(10) NOT NULL,
  `gejala` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`idgejala`, `gejala`) VALUES
('G01', 'Keratinitas'),
('G02', 'Gatal - Gatal'),
('G03', 'Keropeng'),
('G04', 'Ketombe'),
('G05', 'Kutuan'),
('G06', 'Kurus'),
('G07', 'Bulu Rontok'),
('G08', 'Anoreksia'),
('G09', 'Abdomen Keras'),
('G10', 'Muntah'),
('G11', 'Diare'),
('G12', 'Perut Buncit'),
('G13', 'Hilang Nafsu Makan'),
('G14', 'Cacing'),
('G15', 'Pilek'),
('G16', 'Bersin'),
('G17', 'Hidung Tersumbat'),
('G18', 'Badan Lemas'),
('G19', 'Mata Berair'),
('G20', 'Hidung Berair'),
('G21', 'Rigwarm Pada Kulit'),
('G22', 'Kulit Kemeran (Lecet)'),
('G23', 'Jamur'),
('G24', 'Lesi Berminyak'),
('G25', 'Guratan Pada Telinga'),
('G26', 'Adanya Cairan Hitam Pada Telinga'),
('G27', 'Telinga Terdapat Lilin Dan Bau'),
('G28', 'Diare Campur Darah'),
('G29', 'Fases Lembek'),
('G30', 'Minum Kurang'),
('G31', 'Adomen Sakit'),
('G32', 'Tidak Mau Makan'),
('G33', 'Panas'),
('G34', 'Demam'),
('G35', 'Kerak - Kerak Telinga'),
('G36', 'Kotor Pada Sela Jari'),
('G37', 'Kekuningan'),
('G38', 'Makan Kotor'),
('G39', 'Radang'),
('G40', 'Sesak Nafas'),
('G41', 'Radang Mata'),
('G42', 'Sariawan'),
('G43', 'Luka Kulit'),
('G44', 'Bulu Rontok'),
('G45', 'Keluar Nanah Pada Luka'),
('G46', 'Infeksi Saluran Kemih (Jantan)'),
('G47', 'Perut Besar'),
('G48', 'Keluar Ingus');

-- --------------------------------------------------------

--
-- Table structure for table `gejalakucing`
--

CREATE TABLE `gejalakucing` (
  `kode_gejalakucing` varchar(10) NOT NULL,
  `gejalakucing` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `penyakit`
--

CREATE TABLE `penyakit` (
  `idpenyakit` varchar(20) NOT NULL,
  `namapenyakit` varchar(1000) NOT NULL,
  `solusi` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `penyakit`
--

INSERT INTO `penyakit` (`idpenyakit`, `namapenyakit`, `solusi`) VALUES
('P001', 'Scabies', 'Salep Scabies'),
('P002', 'Gastritis', 'Obat Penetral Asam Lambung'),
('P003', 'Dermoto-phytosis', 'Mandi dengan Sampo Jamur 2x dan Obat Anti-Kutu'),
('P004', 'Dermotitis', 'Identifikasi Alergi (Jika Ada) Antibiotic dan Mandi dengan Sampo Anti Bakteri / Jamur 2x Seminggu'),
('P005', 'Helmin Theasis', 'Pemberian Obat Cacing 3 Bulan Sekali'),
('P006', 'Rhinitis', 'Obat Anti Alergi dan Anti Radang'),
('P007', 'Enteritis', 'Makanan Halus, Makanan Butuh Pencernaan, Antibiotic, Anti Diare, dan Obat Cacing'),
('P008', 'Otitis', 'Obat Tetes Telinga dan Anti Radang'),
('P009', 'Sehat', 'Mandi 2 Minggu Sekali'),
('P010', 'Catdistemper', 'Vaksin'),
('P011', 'Rhinotrachetis', 'Vaksin'),
('P012', 'Calcivirus', 'Vaksin'),
('P013', 'Diare / Radang Usus', 'Makan Bersih serta Begizi dan Minum yang Bersih'),
('P014', 'Leptusviruses', 'Vakin, Tidak Boleh Makan Serangga (Tikus dan Kecoa)'),
('P015', 'Jamur', 'Mandi Rutin, Salep Jamur'),
('P016', 'Apses', 'Bersihkan Luka, Antibiotik'),
('P017', 'FLUTD', 'Makanan Bagus, Termetabolisme, Banyak Minum'),
('P018', 'Kutu', 'Mandi, Suntik Kutu, Tetes Kutu');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `iduser` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `nama` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`iduser`, `username`, `password`, `nama`) VALUES
('U001', 'admin', 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`idgejala`);

--
-- Indexes for table `gejalakucing`
--
ALTER TABLE `gejalakucing`
  ADD PRIMARY KEY (`kode_gejalakucing`);

--
-- Indexes for table `penyakit`
--
ALTER TABLE `penyakit`
  ADD PRIMARY KEY (`idpenyakit`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
